const apiUrl = "http://localhost:3000/members";
const enrollmentApiUrl = "http://localhost:3000/enrollments";
const paymentApiUrl = "http://localhost:3000/payments";
const programApiUrl = "http://localhost:3000/workoutPrograms";

// Local Storage
const paymentHistory = JSON.parse(localStorage.getItem('paymentHistory')) || [];
const gymMembers = JSON.parse(localStorage.getItem('gymMember')) || [];

// HTML elements
const tableBody = document.querySelector('#data-table tbody');
const paymentTableBody = document.querySelector('#payment-data-table tbody');
const modalViewPaymentHistory = document.getElementById("modalViewPaymentHistory");
const memberIdDisplay = document.getElementById('memberId');
const paymentModal = document.getElementById('PaymentModal');
const messageDisplay = document.getElementById('message');
const paymentAmountDisplay = document.getElementById('paymentAmount');
const payingProcessButton = document.getElementById('payingProcess');
const searchInput = document.getElementById("searchInput");

// Combine data into a structured format
const combinedData = [];
function combineData() {
    gymMembers.forEach(member => {
        const userPaymentHistory = paymentHistory.find(record => record[0] === member.id) || [];
        const userObj = {
            id: member.id,
            memberDetails: member,
            memberPaymentHistory: userPaymentHistory[1] || []
        };
        combinedData.push(userObj);
    });
}
combineData();

async function fetchData() {
    try {
        const membersResponse = await fetch(apiUrl);
        if (!membersResponse.ok) throw new Error("Members table not found");
        const members = await membersResponse.json();
        
        // Assuming enrollments and payments are needed but not used currently.
        await fetch(enrollmentApiUrl);
        await fetch(paymentApiUrl);

        createTableBody(combinedData);
    } catch (error) {
        console.error(error);
    }  
}

// Create table body with member data
function createTableBody(data) {
    tableBody.innerHTML = data.map(item => `
        <tr>
            <td>${item.userId}</td>
            <td>${item.memberDetails.fname} ${item.memberDetails.lname}</td>
            <td>${item.memberDetails.nicNumber}</td>
            <td>
                <button type="button" class="tablecolor btn" onclick="viewPaymentHistory('${item.id}','${item.userId}')">View Payment History</button>
                <button type="button" class="tablecolor btn" onclick="initiatePayment('${item.id}')">Pay</button>
            </td>
        </tr>
    `).join('');
}
createTableBody(combinedData);

// Search function
function search() {
    const searchValue = searchInput.value;
    const filteredData = combinedData.filter(item => item.id == searchValue);
    createTableBody(filteredData);
}

// Filter options
function filterTable(filterBy) {
    let filteredData;
    if (filterBy === "all") {
        filteredData = combinedData;
    } else if (filterBy === "overdue") {
        const today = new Date().toISOString().split('T')[0];
        filteredData = combinedData.filter(item => today >= item.memberDetails.nxtDueDate);
    } else {
        filteredData = combinedData.filter(item => item.memberDetails.membershipType === filterBy);
    }
    createTableBody(filteredData);
}

async function viewPaymentHistory(id) {
    try {
        const response = await fetch(paymentApiUrl);
        if (!response.ok) throw new Error("Payment history table not found");
        
        const allPaymentHistory = await response.json();
        const userPaymentHistory = allPaymentHistory.filter(record => record.memberId == id);
        
        memberIdDisplay.textContent = id;
        paymentTableBody.innerHTML = userPaymentHistory.map(element => `
            <tr>
                <td>${element.date}</td>
                <td>${element.details}</td>
                <td>${element.amount}</td>
            </tr>
        `).join('');
        
        modalViewPaymentHistory.style.display = 'block';
    } catch (error) {
        console.error(error);
    }
}

function initiatePayment(id) {
    const userDetails = combinedData.find(item => item.id == id);
    const { memberDetails } = userDetails;
    messageDisplay.textContent = `Do you want to pay user ${id} payment?`;
    paymentAmountDisplay.textContent = `Rs. ${memberDetails.payment}`;
    paymentModal.style.display = 'block';

    payingProcessButton.onclick = () => processPayment(memberDetails);
}

function processPayment(personalInfo) {
    const paymentDate = new Date().toISOString().split('T')[0];
    const details = personalInfo.membershipType === "monthlyMembership" ? "Monthly Fee" : "Renewal Fee";
    
    const newPayment = new Payment(personalInfo.payment, details, paymentDate);
    const memberPaymentRecord = paymentHistory.find(item => item[0] === personalInfo.id) || [personalInfo.id, []];
    memberPaymentRecord[1].push(newPayment);
    
    localStorage.setItem('paymentHistory', JSON.stringify(paymentHistory));
    updateMembershipDates(personalInfo);
    
    closeModal(paymentModal);
    location.reload();
}

function updateMembershipDates(personalInfo) {
    const newDueDate = personalInfo.membershipType === "monthlyMembership" ? 
        calculateNextDueDate(personalInfo.nxtDueDate) : 
        calculateRenewalDate(personalInfo.RenewalDate);
    
    personalInfo.membershipType === "monthlyMembership" ?
        personalInfo.nxtDueDate = newDueDate :
        personalInfo.RenewalDate = newDueDate;
    
    localStorage.setItem('gymMember', JSON.stringify(gymMembers));
}

function calculateNextDueDate(currentDueDate) {
    const dueDate = new Date(currentDueDate);
    return `${dueDate.getFullYear()}-${dueDate.getMonth() + 2}-${dueDate.getDate()}`;
}

function calculateRenewalDate(currentDate) {
    const date = new Date(currentDate);
    return `${date.getFullYear() + 1}-${date.getMonth() + 1}-${date.getDate()}`;
}

function closeModal(modal) {
    modal.style.display = 'none';
}
