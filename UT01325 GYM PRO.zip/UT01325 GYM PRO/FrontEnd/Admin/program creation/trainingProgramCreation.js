const apiUrl = "http://localhost:3000/workoutPrograms";

const programIds = JSON.parse(localStorage.getItem('programId')) || [];

const tableBody = document.querySelector('#data-table tbody');
const addProgramModal = document.getElementById("addProgramModal");
const addProgramButton = document.getElementById("addProgram");
const modalTitle = document.getElementById("modalTitle");
const modalViewProgram = document.getElementById("modalVeiwProgram");
const programDetails = document.getElementById("ProgramDetails");
const modalDeleteProgram = document.getElementById("modalDeleteProgram");
const programIdDisplay = document.getElementById("program");
const deleteButton = document.getElementById("Delete");
const modalSubmitButton = document.getElementById("modalSubmit");
const programTitleInput = document.getElementById("title");
const programDescriptionInput = document.getElementById("description");
const initialFeeInput = document.getElementById("initalFee");
const monthlyFeeInput = document.getElementById("monthlyFee");
const annualFeeInput = document.getElementById("annualFee");

const searchInput = document.getElementById("searchInput");

// Fetch and display training programs
async function fetchAndDisplayPrograms() {
    try {
        const response = await fetch(apiUrl);
        if (!response.ok) throw new Error("Table not found");
        const gymTrainingPrograms = await response.json();
        createTableBody(gymTrainingPrograms);
    } catch (error) {
        console.error(error);
    }
}
fetchAndDisplayPrograms();

// Create table body with training programs
function createTableBody(gymTrainingPrograms) {
    tableBody.innerHTML = gymTrainingPrograms.map(item => `
        <tr>
            <td>${item.id}</td>
            <td>${item.title}</td>
            <td>${item.initalFee}</td>
            <td>${item.monthlyFee}</td>
            <td>${item.annualFee}</td>
            <td>${item.description}</td>
            <td>
                <button type="button" class="tablecolor btn" onclick="viewProgramModal('${item.id}')">View</button>
                <button type="button" class="tablecolor btn" onclick="openEditProgramModal('${item.id}')">Edit</button>
                <button type="button" class="tablecolor btn" onclick="confirmDeleteProgram('${item.id}')">Delete</button>
            </td>
        </tr>
    `).join('');
}

// Show add program modal
addProgramButton.onclick = function () {
    addProgramModal.style.display = 'block';
};

// Search function
function search() {
    const searchValue = searchInput.value;
    const filteredData = gymTrainingPrograms.filter(item => item.id == searchValue);
    createTableBody(filteredData);
}

// Handle add program form submission
document.getElementById("trainingProgramCreation").addEventListener("submit", async function (event) {
    event.preventDefault();

    const newTrainingProgram = new Program(
        programTitleInput.value,
        programDescriptionInput.value,
        monthlyFeeInput.value,
        annualFeeInput.value,
        initialFeeInput.value
    );

    newTrainingProgram.createID(programIds);
    localStorage.setItem('programId', JSON.stringify(newTrainingProgram.id));

    await fetch(apiUrl, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(newTrainingProgram)
    });

    event.target.reset();
    fetchAndDisplayPrograms();
    addProgramModal.style.display = 'none';
});

// Open edit program modal
async function openEditProgramModal(id) {
    modalTitle.textContent = `Edit Workout ${id}`;
    const response = await fetch(`${apiUrl}/${id}`);
    const workoutProgram = await response.json();
    populateForm(workoutProgram);
    modalSubmitButton.type = "button";

    modalSubmitButton.onclick = async function () {
        workoutProgram.title = programTitleInput.value;
        workoutProgram.description = programDescriptionInput.value;
        workoutProgram.monthlyFee = monthlyFeeInput.value;
        workoutProgram.annualFee = annualFeeInput.value;
        workoutProgram.initalFee = initialFeeInput.value;

        await fetch(`${apiUrl}/${id}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(workoutProgram)
        });

        fetchAndDisplayPrograms();
        closeModal(addProgramModal); // Close the modal
    };
    addProgramModal.style.display = 'block';
}

// Populate form fields with existing data
function populateForm(data) {
    programTitleInput.value = data.title || '';
    programDescriptionInput.value = data.description || '';
    initialFeeInput.value = data.initalFee || '';
    monthlyFeeInput.value = data.monthlyFee || '';
    annualFeeInput.value = data.annualFee || '';
}

// View program details modal
async function viewProgramModal(id) {
    programDetails.innerHTML = "";
    const response = await fetch(`${apiUrl}/${id}`);
    const workoutProgram = await response.json();

    const detailsHTML = `
        <h1 class="modalTitle">${workoutProgram.title}</h1>
        <p>Program Id: ${workoutProgram.id}</p>
        <p>Initial Fee: ${workoutProgram.initalFee}</p>
        <p>Monthly Fee: ${workoutProgram.monthlyFee}</p>
        <p>Annual Fee: ${workoutProgram.annualFee}</p>
        <p>Further Details: ${workoutProgram.description}</p>
    `;
    programDetails.innerHTML = detailsHTML;
    modalViewProgram.style.display = 'block';
}

// Confirm program deletion
function confirmDeleteProgram(id) {
    programIdDisplay.textContent = id;
    modalDeleteProgram.style.display = "block";
    deleteButton.onclick = async function () {
        await fetch(`${apiUrl}/${id}`, {
            method: "DELETE"
        });
        fetchAndDisplayPrograms();
        closeModal(modalDeleteProgram);
    };
}

// Close modals
function closeModal(modal) {
    modal.style.display = 'none';
    location.reload(); // Reload the page to refresh the data
}
