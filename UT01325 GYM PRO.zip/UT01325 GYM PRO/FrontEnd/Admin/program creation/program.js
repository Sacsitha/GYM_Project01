class ProgramPaymentDetails {
    constructor(monthlyFee, annualFee, initialFee, programId) {
        this.monthlyFee = monthlyFee;
        this.annualFee = annualFee;
        this.initialFee = initialFee;
        this.feeStatus = true; // Improved variable name consistency
        this.programId = programId;

        const date = new Date();
        this.createdDate = `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
    }
}

class Program {
    constructor(title, description, monthlyFee, annualFee, initialFee) {
        this.title = title;
        this.description = description;
        this.programStatus = true;
        this.monthlyFee = monthlyFee;
        this.annualFee = annualFee;
        this.initialFee = initialFee;
        this.createdDate = this.getCurrentDate();
    }

    // Utility function to get the current date
    getCurrentDate() {
        const date = new Date();
        return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
    }

    createID(gymTrainingProgram) {
        try {
            if (gymTrainingProgram.length === 0) {
                this.id = "T" + (100 + gymTrainingProgram.length);
            } else {
                const extractedNum = Number(gymTrainingProgram.slice(1, 4));
                this.id = "T" + (extractedNum + 1);
            }
        } catch (error) {
            console.error("Error creating ID:", error);
        }
    }

    setMonthlyFee(monthlyFee) {
        this.monthlyFee = monthlyFee;
    }

    setAnnualFee(annualFee) {
        this.annualFee = annualFee;
    }

    getMonthlyFee() {
        return this.monthlyFee;
    }

    getAnnualFee() {
        return this.annualFee;
    }

    getId() {
        return this.id;
    }
}
